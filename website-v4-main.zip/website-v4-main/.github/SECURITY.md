# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| Current site version  | :white_check_mark: |
| Any old version | :x: |

## Reporting a Vulnerability

Please open a issue [here](https://github.com/3kh0/website-v4/issues/new?assignees=&labels=%F0%9F%9B%A1+Vulnerability&template=security.md&title=) and we will try to solve it as fast as we can!
